module.exports = {
  secret: 'zhihu-jwt-secret',
  connectionStr: 'mongodb+srv://lewis:mukewang@zhihu-kag3y.mongodb.net/test?retryWrites=true',
};